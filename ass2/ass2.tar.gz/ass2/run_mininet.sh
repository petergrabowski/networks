#!/bin/bash

python2.7 lab3.py
